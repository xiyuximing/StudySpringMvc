/**
 * Support for working with messaging APIs and protocols.
 */
@NonNullApi
@NonNullFields
package org.springframework.messaging;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
