/**
 * Core interfaces for Spring's scripting support.
 */
@NonNullApi
@NonNullFields
package org.springframework.scripting;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
